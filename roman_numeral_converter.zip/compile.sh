 rm -f converter
 gcc -Wall -Werror -Wextra -o converter roman_numeral_converter.c
 
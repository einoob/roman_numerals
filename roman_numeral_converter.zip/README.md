# roman_numerals
Translates roman numerals to arabic system (base 10).

Compile program by running 'sh compile.sh'

Convert roman numerals to arabic system by running './converter'
You can give multiple numbers at once. Converter prints every number (or error message)
followed by a new line.

Example:
./converter I MCCXXXIV MMXX ABCD
1
1234
2020
Invalid input: allowed characters are 'I V X L C D M -'.
